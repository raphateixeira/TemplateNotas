# Modelo de Projeto de Apresentações em Quarto

Estrutura reutilizável para uma disciplina com notas de aula em slides
(Reveal.js) e um portal de navegação (HTML). Copie esta pasta, renomeie
e adapte para qualquer tema.

## Estrutura

```
Template/
├── _quarto.yml              configuração do site e da navbar
├── TemaModelo.scss          tema visual (cores/fontes no topo do arquivo)
├── index.qmd                portal com os links das aulas
└── Notas/
    ├── Aula00PlanoEnsino.qmd   molde do plano de ensino
    ├── Aula01Exemplo.qmd       aula-exemplo comentada (todos os recursos)
    └── imgs/
        ├── Logo.png            logotipo da capa
        └── tikz/
            └── ExemploDiagrama.tikz   esquema em TikZ
```

## Como adaptar

1. **Identidade visual:** edite as variáveis no topo de `TemaModelo.scss`
   (`$cor-primaria`, `$cor-secundaria`, ...). Atualize a cor da navbar em
   `_quarto.yml` para o mesmo valor da cor primária.
2. **Logo:** substitua `Notas/imgs/Logo.png`.
3. **Metadados:** troque os campos `<<< EDITAR` em `_quarto.yml` e os
   cabeçalhos YAML (`title`, `subtitle`, `institute`, `author`) de cada `.qmd`.
4. **Aulas:** copie `Aula01Exemplo.qmd`, renomeie, escreva o conteúdo e
   adicione a entrada correspondente em `index.qmd` e no menu do `_quarto.yml`.

## Recursos demonstrados em `Aula01Exemplo.qmd`

- Slides 16:9, duas colunas, callouts (`note`, `important`, `tip`);
- Matemática em LaTeX (linha e destaque), matrizes;
- Exemplo passo a passo;
- Código em abas (`panel-tabset`) para múltiplas linguagens;
- Figura em **TikZ** (`\input` de `imgs/tikz/`) e figura de imagem;
- Tabela e lista de exercícios.

## Renderização

Dentro da pasta do projeto:

```bash
quarto preview      # servidor local com navegação
quarto render       # gera o site em _site/
```

### Pré-requisitos

- **Quarto** instalado.
- **LaTeX** para os diagramas TikZ: `quarto install tinytex`.
- Pacote **R `magick`** (o engine TikZ converte PDF→PNG por meio dele):
  ```r
  install.packages("magick")
  ```
  No Linux, instale também a biblioteca de sistema (ex.: Ubuntu:
  `sudo apt install libmagick++-dev`).

### Observações sobre os chunks TikZ

- As opções de um chunk ```` ```{tikz} ```` começam com `%|`
  (comentário LaTeX), **não** com `#|`. Cada linguagem usa o seu próprio
  caractere de comentário para as opções de chunk.
- Carregue as bibliotecas TikZ necessárias no próprio chunk, com
  `\usetikzlibrary{...}`, antes do `\input`.
